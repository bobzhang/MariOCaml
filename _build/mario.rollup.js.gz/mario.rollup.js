(function () {
'use strict';

var failure = /* tuple */[
  "Failure",
  -2
];

var invalid_argument = /* tuple */[
  "Invalid_argument",
  -3
];

var division_by_zero = /* tuple */[
  "Division_by_zero",
  -5
];

failure.tag = 248;

invalid_argument.tag = 248;

division_by_zero.tag = 248;


/*  Not a pure module */

function caml_array_sub(x, offset, len) {
  var result = new Array(len);
  var j = 0;
  var i = offset;
  while(j < len) {
    result[j] = x[i];
    j = j + 1 | 0;
    i = i + 1 | 0;
  }
  return result;
}


/* No side effect */

function app(_f, _args) {
  while(true) {
    var args = _args;
    var f = _f;
    var arity = f.length;
    var arity$1 = arity ? arity : 1;
    var len = args.length;
    var d = arity$1 - len | 0;
    if (d) {
      if (d < 0) {
        _args = caml_array_sub(args, arity$1, -d | 0);
        _f = f.apply(null, caml_array_sub(args, 0, arity$1));
        continue ;
        
      } else {
        return (function(f,args){
        return function (x) {
          return app(f, args.concat(/* array */[x]));
        }
        }(f,args));
      }
    } else {
      return f.apply(null, args);
    }
  }
}

function curry_1(o, a0, arity) {
  if (arity > 7 || arity < 0) {
    return app(o, /* array */[a0]);
  } else {
    switch (arity) {
      case 0 : 
      case 1 : 
          return o(a0);
      case 2 : 
          return function (param) {
            return o(a0, param);
          };
      case 3 : 
          return function (param, param$1) {
            return o(a0, param, param$1);
          };
      case 4 : 
          return function (param, param$1, param$2) {
            return o(a0, param, param$1, param$2);
          };
      case 5 : 
          return function (param, param$1, param$2, param$3) {
            return o(a0, param, param$1, param$2, param$3);
          };
      case 6 : 
          return function (param, param$1, param$2, param$3, param$4) {
            return o(a0, param, param$1, param$2, param$3, param$4);
          };
      case 7 : 
          return function (param, param$1, param$2, param$3, param$4, param$5) {
            return o(a0, param, param$1, param$2, param$3, param$4, param$5);
          };
      
    }
  }
}

function _1(o, a0) {
  var arity = o.length;
  if (arity === 1) {
    return o(a0);
  } else {
    return curry_1(o, a0, arity);
  }
}

function curry_2(o, a0, a1, arity) {
  if (arity > 7 || arity < 0) {
    return app(o, /* array */[
                a0,
                a1
              ]);
  } else {
    switch (arity) {
      case 0 : 
      case 1 : 
          return app(o(a0), /* array */[a1]);
      case 2 : 
          return o(a0, a1);
      case 3 : 
          return function (param) {
            return o(a0, a1, param);
          };
      case 4 : 
          return function (param, param$1) {
            return o(a0, a1, param, param$1);
          };
      case 5 : 
          return function (param, param$1, param$2) {
            return o(a0, a1, param, param$1, param$2);
          };
      case 6 : 
          return function (param, param$1, param$2, param$3) {
            return o(a0, a1, param, param$1, param$2, param$3);
          };
      case 7 : 
          return function (param, param$1, param$2, param$3, param$4) {
            return o(a0, a1, param, param$1, param$2, param$3, param$4);
          };
      
    }
  }
}

function _2(o, a0, a1) {
  var arity = o.length;
  if (arity === 2) {
    return o(a0, a1);
  } else {
    return curry_2(o, a0, a1, arity);
  }
}


/* No side effect */

function __(tag, block) {
  block.tag = tag;
  return block;
}


/* No side effect */

function caml_int_compare(x, y) {
  if (x < y) {
    return -1;
  } else if (x === y) {
    return 0;
  } else {
    return 1;
  }
}

function caml_compare(_a, _b) {
  while(true) {
    var b = _b;
    var a = _a;
    var a_type = typeof a;
    var b_type = typeof b;
    if (a_type === "string") {
      var x = a;
      var y = b;
      if (x < y) {
        return -1;
      } else if (x === y) {
        return 0;
      } else {
        return 1;
      }
    } else {
      var is_a_number = +(a_type === "number");
      var is_b_number = +(b_type === "number");
      if (is_a_number !== 0) {
        if (is_b_number !== 0) {
          return caml_int_compare(a, b);
        } else {
          return -1;
        }
      } else if (is_b_number !== 0) {
        return 1;
      } else if (a_type === "boolean" || a_type === "null" || a_type === "undefined") {
        var x$1 = a;
        var y$1 = b;
        if (x$1 === y$1) {
          return 0;
        } else if (x$1 < y$1) {
          return -1;
        } else {
          return 1;
        }
      } else if (a_type === "function" || b_type === "function") {
        throw [
              invalid_argument,
              "compare: functional value"
            ];
      } else {
        var tag_a = a.tag | 0;
        var tag_b = b.tag | 0;
        if (tag_a === 250) {
          _a = a[0];
          continue ;
          
        } else if (tag_b === 250) {
          _b = b[0];
          continue ;
          
        } else if (tag_a === 248) {
          return caml_int_compare(a[1], b[1]);
        } else if (tag_a === 251) {
          throw [
                invalid_argument,
                "equal: abstract value"
              ];
        } else if (tag_a !== tag_b) {
          if (tag_a < tag_b) {
            return -1;
          } else {
            return 1;
          }
        } else {
          var len_a = a.length;
          var len_b = b.length;
          if (len_a === len_b) {
            var a$1 = a;
            var b$1 = b;
            var _i = 0;
            var same_length = len_a;
            while(true) {
              var i = _i;
              if (i === same_length) {
                return 0;
              } else {
                var res = caml_compare(a$1[i], b$1[i]);
                if (res !== 0) {
                  return res;
                } else {
                  _i = i + 1 | 0;
                  continue ;
                  
                }
              }
            }
          } else if (len_a < len_b) {
            var a$2 = a;
            var b$2 = b;
            var _i$1 = 0;
            var short_length = len_a;
            while(true) {
              var i$1 = _i$1;
              if (i$1 === short_length) {
                return -1;
              } else {
                var res$1 = caml_compare(a$2[i$1], b$2[i$1]);
                if (res$1 !== 0) {
                  return res$1;
                } else {
                  _i$1 = i$1 + 1 | 0;
                  continue ;
                  
                }
              }
            }
          } else {
            var a$3 = a;
            var b$3 = b;
            var _i$2 = 0;
            var short_length$1 = len_b;
            while(true) {
              var i$2 = _i$2;
              if (i$2 === short_length$1) {
                return 1;
              } else {
                var res$2 = caml_compare(a$3[i$2], b$3[i$2]);
                if (res$2 !== 0) {
                  return res$2;
                } else {
                  _i$2 = i$2 + 1 | 0;
                  continue ;
                  
                }
              }
            }
          }
        }
      }
    }
  }
}

function caml_lessequal(a, b) {
  return +(caml_compare(a, b) <= 0);
}


/* No side effect */

/* stdin Not a pure module */

/* No side effect */

function mod_(x, y) {
  if (y === 0) {
    throw division_by_zero;
  } else {
    return x % y;
  }
}

var imul = ( Math.imul || function (x,y) {
  y |= 0; return ((((x >> 16) * y) << 16) + (x & 0xffff) * y)|0; 
}
);


/* imul Not a pure module */

/* repeat Not a pure module */

/* two_ptr_32_dbl Not a pure module */

/* float_of_string Not a pure module */

/* No side effect */

/* No side effect */

/* not_implemented Not a pure module */

/* No side effect */

function failwith(s) {
  throw [
        failure,
        s
      ];
}

function min(x, y) {
  if (caml_lessequal(x, y)) {
    return x;
  } else {
    return y;
  }
}

var min_int = -2147483648;

function string_of_int(param) {
  return "" + param;
}

function $at(l1, l2) {
  if (l1) {
    return /* :: */[
            l1[0],
            $at(l1[1], l2)
          ];
  } else {
    return l2;
  }
}

var max_int = 2147483647;


/* No side effect */

function rev_append(_l1, _l2) {
  while(true) {
    var l2 = _l2;
    var l1 = _l1;
    if (l1) {
      _l2 = /* :: */[
        l1[0],
        l2
      ];
      _l1 = l1[1];
      continue ;
      
    } else {
      return l2;
    }
  }
}

function map(f, param) {
  if (param) {
    var r = _1(f, param[0]);
    return /* :: */[
            r,
            map(f, param[1])
          ];
  } else {
    return /* [] */0;
  }
}

function iter(f, _param) {
  while(true) {
    var param = _param;
    if (param) {
      _1(f, param[0]);
      _param = param[1];
      continue ;
      
    } else {
      return /* () */0;
    }
  }
}

function fold_left(f, _accu, _l) {
  while(true) {
    var l = _l;
    var accu = _accu;
    if (l) {
      _l = l[1];
      _accu = _2(f, accu, l[0]);
      continue ;
      
    } else {
      return accu;
    }
  }
}

function find_all(p) {
  return function (param) {
    var _accu = /* [] */0;
    var _param = param;
    while(true) {
      var param$1 = _param;
      var accu = _accu;
      if (param$1) {
        var l = param$1[1];
        var x = param$1[0];
        if (_1(p, x)) {
          _param = l;
          _accu = /* :: */[
            x,
            accu
          ];
          continue ;
          
        } else {
          _param = l;
          continue ;
          
        }
      } else {
        return rev_append(accu, /* [] */0);
      }
    }
  };
}

var filter = find_all;


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function render_bbox(sprite, param) {
  var context = sprite[/* context */1];
  var match = sprite[/* params */0][/* bbox_offset */5];
  var match$1 = sprite[/* params */0][/* bbox_size */6];
  context.strokeStyle = "#FF0000";
  return context.strokeRect(param[0] + match[0], param[1] + match[1], match$1[0], match$1[1]);
}

function render(sprite, param) {
  var context = sprite[/* context */1];
  var match = sprite[/* params */0][/* src_offset */4];
  var match$1 = sprite[/* params */0][/* frame_size */3];
  var sw = match$1[0];
  var match$2 = sprite[/* params */0][/* frame_size */3];
  var sx = match[0] + sprite[/* frame */2][0] * sw;
  return context.drawImage(sprite[/* img */4], sx, match[1], sw, match$1[1], param[0], param[1], match$2[0], match$2[1]);
}

function draw_bgd(bgd, off_x) {
  render(bgd, /* tuple */[
        -off_x,
        0
      ]);
  return render(bgd, /* tuple */[
              bgd[/* params */0][/* frame_size */3][0] - off_x,
              0
            ]);
}

function clear_canvas(canvas) {
  var context = canvas.getContext("2d");
  var cwidth = canvas.width;
  var cheight = canvas.height;
  context.clearRect(0, 0, cwidth, cheight);
  return /* () */0;
}

function hud(canvas, score, coins) {
  var score_string = string_of_int(score);
  var coin_string = string_of_int(coins);
  var context = canvas.getContext("2d");
  context.font = "10px 'Press Start 2P'";
  context.fillText("Score: " + score_string, canvas.width - 140, 18);
  context.fillText("Coins: " + coin_string, 120, 18);
  return /* () */0;
}

function fps(canvas, fps_val) {
  var fps_str = string_of_int(fps_val | 0);
  var context = canvas.getContext("2d");
  context.fillText(fps_str, 10, 18);
  return /* () */0;
}

function game_win(ctx) {
  ctx.rect(0, 0, 512, 512);
  ctx.fillStyle = "black";
  ctx.fill();
  ctx.fillStyle = "white";
  ctx.font = "20px 'Press Start 2P'";
  ctx.fillText("You win!", 180, 128);
  return failwith("Game over.");
}

function game_loss(ctx) {
  ctx.rect(0, 0, 512, 512);
  ctx.fillStyle = "black";
  ctx.fill();
  ctx.fillStyle = "white";
  ctx.font = "20px 'Press Start 2P'";
  ctx.fillText("GAME OVER. You lose!", 60, 128);
  return failwith("Game over.");
}


/*  Not a pure module */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function eq_dir_1d(x, y) {
  if (x !== 0) {
    return +(y === /* Right */1);
  } else {
    return +(y === /* Left */0);
  }
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function eq_checkloc(param, param$1) {
  if (param[0] === param$1[0]) {
    return +(param[1] === param$1[1]);
  } else {
    return /* false */0;
  }
}

function max_float$1(a, b) {
  if (a > b) {
    return a;
  } else {
    return b;
  }
}

function min_float$1(a, b) {
  if (a < b) {
    return a;
  } else {
    return b;
  }
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
var zero_bbox_size = /* tuple */[
  0,
  0
];

function setup_sprite($staropt$star, $staropt$star$1, $staropt$star$2, img_src, max_frames, max_ticks, frame_size, src_offset) {
  var loop = $staropt$star ? $staropt$star[0] : /* true */1;
  var bbox_offset = $staropt$star$1 ? $staropt$star$1[0] : /* tuple */[
      0,
      0
    ];
  var bbox_size = $staropt$star$2 ? $staropt$star$2[0] : zero_bbox_size;
  var bbox_size$1 = eq_checkloc(bbox_size, zero_bbox_size) ? frame_size : bbox_size;
  var img_src$1 = "./sprites/" + img_src;
  return /* record */[
          /* max_frames */max_frames,
          /* max_ticks */max_ticks,
          /* img_src */img_src$1,
          /* frame_size */frame_size,
          /* src_offset */src_offset,
          /* bbox_offset */bbox_offset,
          /* bbox_size */bbox_size$1,
          /* loop */loop
        ];
}

function make_enemy(param) {
  var dir = param[1];
  switch (param[0]) {
    case 0 : 
        return setup_sprite(/* None */0, /* Some */[/* tuple */[
                      1,
                      1
                    ]], /* Some */[/* tuple */[
                      14,
                      14
                    ]], "enemies.png", 2, 10, /* tuple */[
                    16,
                    16
                  ], /* tuple */[
                    0,
                    128
                  ]);
    case 1 : 
        if (dir !== 0) {
          return setup_sprite(/* None */0, /* Some */[/* tuple */[
                        1,
                        10
                      ]], /* Some */[/* tuple */[
                        11,
                        16
                      ]], "enemies.png", 2, 10, /* tuple */[
                      16,
                      27
                    ], /* tuple */[
                      32,
                      69
                    ]);
        } else {
          return setup_sprite(/* None */0, /* Some */[/* tuple */[
                        4,
                        10
                      ]], /* Some */[/* tuple */[
                        11,
                        16
                      ]], "enemies.png", 2, 10, /* tuple */[
                      16,
                      27
                    ], /* tuple */[
                      0,
                      69
                    ]);
        }
    case 2 : 
        if (dir !== 0) {
          return setup_sprite(/* None */0, /* Some */[/* tuple */[
                        1,
                        10
                      ]], /* Some */[/* tuple */[
                        11,
                        16
                      ]], "enemies.png", 2, 10, /* tuple */[
                      16,
                      27
                    ], /* tuple */[
                      32,
                      5
                    ]);
        } else {
          return setup_sprite(/* None */0, /* Some */[/* tuple */[
                        4,
                        10
                      ]], /* Some */[/* tuple */[
                        11,
                        16
                      ]], "enemies.png", 2, 10, /* tuple */[
                      16,
                      27
                    ], /* tuple */[
                      0,
                      5
                    ]);
        }
    case 3 : 
        return setup_sprite(/* None */0, /* Some */[/* tuple */[
                      2,
                      2
                    ]], /* Some */[/* tuple */[
                      12,
                      13
                    ]], "enemies.png", 4, 10, /* tuple */[
                    16,
                    16
                  ], /* tuple */[
                    0,
                    96
                  ]);
    case 4 : 
        return setup_sprite(/* None */0, /* Some */[/* tuple */[
                      2,
                      2
                    ]], /* Some */[/* tuple */[
                      12,
                      13
                    ]], "enemies.png", 4, 10, /* tuple */[
                    16,
                    16
                  ], /* tuple */[
                    0,
                    32
                  ]);
    
  }
}

function make_particle(param) {
  switch (param) {
    case 0 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "enemies.png", 1, 0, /* tuple */[
                    16,
                    16
                  ], /* tuple */[
                    0,
                    144
                  ]);
    case 1 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "chunks.png", 1, 0, /* tuple */[
                    8,
                    8
                  ], /* tuple */[
                    0,
                    0
                  ]);
    case 2 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "chunks.png", 1, 0, /* tuple */[
                    8,
                    8
                  ], /* tuple */[
                    8,
                    0
                  ]);
    case 3 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    12,
                    8
                  ], /* tuple */[
                    0,
                    0
                  ]);
    case 4 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    12,
                    9
                  ], /* tuple */[
                    0,
                    9
                  ]);
    case 5 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    12,
                    9
                  ], /* tuple */[
                    0,
                    18
                  ]);
    case 6 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    12,
                    9
                  ], /* tuple */[
                    0,
                    27
                  ]);
    case 7 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    14,
                    9
                  ], /* tuple */[
                    13,
                    0
                  ]);
    case 8 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    14,
                    9
                  ], /* tuple */[
                    13,
                    9
                  ]);
    case 9 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    14,
                    9
                  ], /* tuple */[
                    13,
                    18
                  ]);
    case 10 : 
        return setup_sprite(/* None */0, /* None */0, /* None */0, "score.png", 1, 0, /* tuple */[
                    14,
                    9
                  ], /* tuple */[
                    13,
                    27
                  ]);
    
  }
}

function make_type$1(typ, dir) {
  switch (typ.tag | 0) {
    case 0 : 
        var pt = typ[0];
        var spr_type = /* tuple */[
          typ[1],
          dir
        ];
        if (pt !== 0) {
          var param = spr_type;
          var typ$1 = param[0];
          if (param[1] !== 0) {
            switch (typ$1) {
              case 0 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                1,
                                1
                              ]], /* Some */[/* tuple */[
                                11,
                                15
                              ]], "mario-small.png", 1, 0, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              0,
                              32
                            ]);
              case 1 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                15
                              ]], "mario-small.png", 2, 10, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              16,
                              48
                            ]);
              case 2 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                12,
                                15
                              ]], "mario-small.png", 3, 5, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              16,
                              32
                            ]);
              case 3 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                1,
                                5
                              ]], /* Some */[/* tuple */[
                                14,
                                10
                              ]], "mario-small.png", 1, 0, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              0,
                              64
                            ]);
              
            }
          } else {
            switch (typ$1) {
              case 0 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                3,
                                1
                              ]], /* Some */[/* tuple */[
                                11,
                                15
                              ]], "mario-small.png", 1, 0, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              0,
                              0
                            ]);
              case 1 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                15
                              ]], "mario-small.png", 2, 10, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              16,
                              16
                            ]);
              case 2 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                12,
                                15
                              ]], "mario-small.png", 3, 5, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              16,
                              0
                            ]);
              case 3 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                1,
                                5
                              ]], /* Some */[/* tuple */[
                                14,
                                10
                              ]], "mario-small.png", 1, 0, /* tuple */[
                              16,
                              16
                            ], /* tuple */[
                              0,
                              64
                            ]);
              
            }
          }
        } else {
          var param$1 = spr_type;
          var typ$2 = param$1[0];
          if (param$1[1] !== 0) {
            switch (typ$2) {
              case 0 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                1,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                25
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              26
                            ], /* tuple */[
                              16,
                              69
                            ]);
              case 1 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                12,
                                25
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              26
                            ], /* tuple */[
                              48,
                              70
                            ]);
              case 2 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                25
                              ]], "mario-big.png", 4, 10, /* tuple */[
                              16,
                              27
                            ], /* tuple */[
                              0,
                              101
                            ]);
              case 3 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                10
                              ]], /* Some */[/* tuple */[
                                13,
                                17
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              27
                            ], /* tuple */[
                              32,
                              69
                            ]);
              
            }
          } else {
            switch (typ$2) {
              case 0 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                25
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              27
                            ], /* tuple */[
                              16,
                              5
                            ]);
              case 1 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                12,
                                25
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              26
                            ], /* tuple */[
                              48,
                              6
                            ]);
              case 2 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                1
                              ]], /* Some */[/* tuple */[
                                13,
                                25
                              ]], "mario-big.png", 4, 10, /* tuple */[
                              16,
                              27
                            ], /* tuple */[
                              0,
                              37
                            ]);
              case 3 : 
                  return setup_sprite(/* None */0, /* Some */[/* tuple */[
                                2,
                                10
                              ]], /* Some */[/* tuple */[
                                13,
                                17
                              ]], "mario-big.png", 1, 0, /* tuple */[
                              16,
                              27
                            ], /* tuple */[
                              32,
                              5
                            ]);
              
            }
          }
        }
    case 1 : 
        return make_enemy(/* tuple */[
                    typ[0],
                    dir
                  ]);
    case 2 : 
        var param$2 = typ[0];
        switch (param$2) {
          case 0 : 
              return setup_sprite(/* None */0, /* Some */[/* tuple */[
                            2,
                            0
                          ]], /* Some */[/* tuple */[
                            12,
                            16
                          ]], "items.png", 1, 0, /* tuple */[
                          16,
                          16
                        ], /* tuple */[
                          0,
                          0
                        ]);
          case 1 : 
              return setup_sprite(/* None */0, /* None */0, /* None */0, "items.png", 1, 0, /* tuple */[
                          16,
                          16
                        ], /* tuple */[
                          0,
                          188
                        ]);
          case 2 : 
              return setup_sprite(/* None */0, /* None */0, /* None */0, "items.png", 1, 0, /* tuple */[
                          16,
                          16
                        ], /* tuple */[
                          16,
                          48
                        ]);
          case 3 : 
              return setup_sprite(/* None */0, /* Some */[/* tuple */[
                            3,
                            0
                          ]], /* Some */[/* tuple */[
                            12,
                            16
                          ]], "items.png", 3, 15, /* tuple */[
                          16,
                          16
                        ], /* tuple */[
                          0,
                          80
                        ]);
          
        }
    case 3 : 
        var param$3 = typ[0];
        if (typeof param$3 === "number") {
          switch (param$3) {
            case 0 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "blocks.png", 1, 0, /* tuple */[
                            16,
                            16
                          ], /* tuple */[
                            0,
                            32
                          ]);
            case 1 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "blocks.png", 5, 10, /* tuple */[
                            16,
                            16
                          ], /* tuple */[
                            0,
                            0
                          ]);
            case 2 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "blocks.png", 1, 0, /* tuple */[
                            16,
                            16
                          ], /* tuple */[
                            0,
                            48
                          ]);
            case 3 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "blocks.png", 1, 0, /* tuple */[
                            16,
                            16
                          ], /* tuple */[
                            0,
                            64
                          ]);
            case 4 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "panel.png", 3, 15, /* tuple */[
                            26,
                            26
                          ], /* tuple */[
                            0,
                            0
                          ]);
            case 5 : 
                return setup_sprite(/* None */0, /* None */0, /* None */0, "ground.png", 1, 0, /* tuple */[
                            16,
                            16
                          ], /* tuple */[
                            0,
                            32
                          ]);
            
          }
        } else {
          return setup_sprite(/* None */0, /* None */0, /* None */0, "blocks.png", 4, 15, /* tuple */[
                      16,
                      16
                    ], /* tuple */[
                      0,
                      16
                    ]);
        }
    
  }
}

function make_from_params(params, context) {
  var img = document.createElement("img");
  img.src = params[/* img_src */2];
  return /* record */[
          /* params */params,
          /* context */context,
          /* frame */[0],
          /* ticks */[0],
          /* img */img
        ];
}

function make$1(spawn, dir, context) {
  var params = make_type$1(spawn, dir);
  return make_from_params(params, context);
}

function make_bgd(context) {
  var params = setup_sprite(/* None */0, /* None */0, /* None */0, "bgd-1.png", 1, 0, /* tuple */[
        512,
        256
      ], /* tuple */[
        0,
        0
      ]);
  return make_from_params(params, context);
}

function make_particle$1(ptyp, context) {
  var params = make_particle(ptyp);
  return make_from_params(params, context);
}

function transform_enemy(enemy_typ, spr, dir) {
  var params = make_enemy(/* tuple */[
        enemy_typ,
        dir
      ]);
  var img = document.createElement("img");
  img.src = params[/* img_src */2];
  spr[/* params */0] = params;
  spr[/* img */4] = img;
  return /* () */0;
}

function update_animation(spr) {
  var curr_ticks = spr[/* ticks */3][0];
  if (curr_ticks >= spr[/* params */0][/* max_ticks */1]) {
    spr[/* ticks */3][0] = 0;
    if (spr[/* params */0][/* loop */7]) {
      spr[/* frame */2][0] = mod_(spr[/* frame */2][0] + 1 | 0, spr[/* params */0][/* max_frames */0]);
      return /* () */0;
    } else {
      return 0;
    }
  } else {
    spr[/* ticks */3][0] = curr_ticks + 1 | 0;
    return /* () */0;
  }
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function pair_to_xy(pair) {
  return /* float array */[
          pair[0],
          pair[1]
        ];
}

function make_type$2(typ, ctx) {
  if (typ === 2 || typ === 1) {
    return /* record */[
            /* sprite */make_particle$1(typ, ctx),
            /* rot */0,
            /* lifetime */300
          ];
  } else {
    return /* record */[
            /* sprite */make_particle$1(typ, ctx),
            /* rot */0,
            /* lifetime */30
          ];
  }
}

function make$2($staropt$star, $staropt$star$1, part_type, pos, ctx) {
  var vel = $staropt$star ? $staropt$star[0] : /* tuple */[
      0,
      0
    ];
  var acc = $staropt$star$1 ? $staropt$star$1[0] : /* tuple */[
      0,
      0
    ];
  var params = make_type$2(part_type, ctx);
  var pos$1 = pair_to_xy(pos);
  var vel$1 = pair_to_xy(vel);
  var acc$1 = pair_to_xy(acc);
  return /* record */[
          /* params */params,
          /* part_type */part_type,
          /* pos */pos$1,
          /* vel */vel$1,
          /* acc */acc$1,
          /* kill : false */0,
          /* life */params[/* lifetime */2]
        ];
}

function make_score(score, pos, ctx) {
  var t = score >= 801 ? (
      score >= 2001 ? (
          score !== 4000 ? (
              score !== 8000 ? /* Score100 */3 : /* Score8000 */10
            ) : /* Score4000 */9
        ) : (
          score !== 1000 ? (
              score >= 2000 ? /* Score2000 */8 : /* Score100 */3
            ) : /* Score1000 */7
        )
    ) : (
      score >= 201 ? (
          score !== 400 ? (
              score >= 800 ? /* Score800 */6 : /* Score100 */3
            ) : /* Score400 */5
        ) : (
          score !== 100 && score >= 200 ? /* Score200 */4 : /* Score100 */3
        )
    );
  return make$2(/* Some */[/* tuple */[
                0.5,
                -0.7
              ]], /* None */0, t, pos, ctx);
}

function update_vel$1(part) {
  part[/* vel */3][/* x */0] = part[/* vel */3][/* x */0] + part[/* acc */4][/* x */0];
  part[/* vel */3][/* y */1] = part[/* vel */3][/* y */1] + part[/* acc */4][/* y */1];
  return /* () */0;
}

function $$process(part) {
  part[/* life */6] = part[/* life */6] - 1 | 0;
  if (!part[/* life */6]) {
    part[/* kill */5] = /* true */1;
  }
  update_vel$1(part);
  var part$1 = part;
  part$1[/* pos */2][/* x */0] = part$1[/* vel */3][/* x */0] + part$1[/* pos */2][/* x */0];
  part$1[/* pos */2][/* y */1] = part$1[/* vel */3][/* y */1] + part$1[/* pos */2][/* y */1];
  return /* () */0;
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
var id_counter = [min_int];

function setup_obj($staropt$star, $staropt$star$1, _) {
  var has_gravity = $staropt$star ? $staropt$star[0] : /* true */1;
  var speed = $staropt$star$1 ? $staropt$star$1[0] : 1;
  return /* record */[
          /* has_gravity */has_gravity,
          /* speed */speed
        ];
}

function set_vel_to_speed(obj) {
  var speed = obj[/* params */0][/* speed */1];
  var match = obj[/* dir */6];
  if (match !== 0) {
    obj[/* vel */2][/* x */0] = speed;
    return /* () */0;
  } else {
    obj[/* vel */2][/* x */0] = -speed;
    return /* () */0;
  }
}

function make_type(param) {
  switch (param.tag | 0) {
    case 0 : 
        return setup_obj(/* None */0, /* Some */[2.8], /* () */0);
    case 1 : 
        var param$1 = param[0];
        if (param$1 >= 3) {
          return setup_obj(/* None */0, /* Some */[3], /* () */0);
        } else {
          return setup_obj(/* None */0, /* None */0, /* () */0);
        }
    case 2 : 
        var param$2 = param[0];
        if (param$2 >= 3) {
          return setup_obj(/* Some */[/* false */0], /* None */0, /* () */0);
        } else {
          return setup_obj(/* None */0, /* None */0, /* () */0);
        }
    case 3 : 
        return setup_obj(/* Some */[/* false */0], /* None */0, /* () */0);
    
  }
}

function new_id() {
  id_counter[0] = id_counter[0] + 1 | 0;
  return id_counter[0];
}

function make$$1($staropt$star, $staropt$star$1, spawnable, context, param) {
  var id = $staropt$star ? $staropt$star[0] : /* None */0;
  var dir = $staropt$star$1 ? $staropt$star$1[0] : /* Left */0;
  var spr = make$1(spawnable, dir, context);
  var params = make_type(spawnable);
  var id$1 = id ? id[0] : new_id(/* () */0);
  var obj = /* record */[
    /* params */params,
    /* pos : float array */[
      param[0],
      param[1]
    ],
    /* vel : float array */[
      0.0,
      0.0
    ],
    /* id */id$1,
    /* jumping : false */0,
    /* grounded : false */0,
    /* dir */dir,
    /* invuln */0,
    /* kill : false */0,
    /* health */1,
    /* crouch : false */0,
    /* score */0
  ];
  return /* tuple */[
          spr,
          obj
        ];
}

function spawn(spawnable, context, param) {
  var match = make$$1(/* None */0, /* None */0, spawnable, context, /* tuple */[
        param[0],
        param[1]
      ]);
  var obj = match[1];
  var spr = match[0];
  switch (spawnable.tag | 0) {
    case 0 : 
        return /* Player */__(0, [
                  spawnable[0],
                  spr,
                  obj
                ]);
    case 1 : 
        set_vel_to_speed(obj);
        return /* Enemy */__(1, [
                  spawnable[0],
                  spr,
                  obj
                ]);
    case 2 : 
        return /* Item */__(2, [
                  spawnable[0],
                  spr,
                  obj
                ]);
    case 3 : 
        return /* Block */__(3, [
                  spawnable[0],
                  spr,
                  obj
                ]);
    
  }
}

function get_sprite(param) {
  return param[1];
}

function get_obj(param) {
  return param[2];
}

function is_player(param) {
  if (param.tag) {
    return /* false */0;
  } else {
    return /* true */1;
  }
}

function is_enemy(param) {
  if (param.tag === 1) {
    return /* true */1;
  } else {
    return /* false */0;
  }
}

function equals(col1, col2) {
  return +(col1[2][/* id */3] === col2[2][/* id */3]);
}

function normalize_pos(pos, p1, p2) {
  var match = p1[/* bbox_offset */5];
  var match$1 = p2[/* bbox_offset */5];
  var match$2 = p1[/* bbox_size */6];
  var match$3 = p2[/* bbox_size */6];
  pos[/* x */0] = pos[/* x */0] - (match$3[0] + match$1[0]) + (match$2[0] + match[0]);
  pos[/* y */1] = pos[/* y */1] - (match$3[1] + match$1[1]) + (match$2[1] + match[1]);
  return /* () */0;
}

function update_player(player, keys, context) {
  var prev_jumping = player[/* jumping */4];
  var prev_dir = player[/* dir */6];
  var prev_vx = Math.abs(player[/* vel */2][/* x */0]);
  iter(function (param) {
        var player$1 = player;
        var controls = param;
        var lr_acc = player$1[/* vel */2][/* x */0] * 0.2;
        switch (controls) {
          case 0 : 
              if (player$1[/* crouch */10]) {
                return 0;
              } else {
                if (player$1[/* vel */2][/* x */0] > -player$1[/* params */0][/* speed */1]) {
                  player$1[/* vel */2][/* x */0] = player$1[/* vel */2][/* x */0] - (0.4 - lr_acc);
                }
                player$1[/* dir */6] = /* Left */0;
                return /* () */0;
              }
              break;
          case 1 : 
              if (player$1[/* crouch */10]) {
                return 0;
              } else {
                if (player$1[/* vel */2][/* x */0] < player$1[/* params */0][/* speed */1]) {
                  player$1[/* vel */2][/* x */0] = player$1[/* vel */2][/* x */0] + (0.4 + lr_acc);
                }
                player$1[/* dir */6] = /* Right */1;
                return /* () */0;
              }
              break;
          case 2 : 
              if (!player$1[/* jumping */4] && player$1[/* grounded */5]) {
                player$1[/* jumping */4] = /* true */1;
                player$1[/* grounded */5] = /* false */0;
                player$1[/* vel */2][/* y */1] = max_float$1(player$1[/* vel */2][/* y */1] - (5.7 + Math.abs(player$1[/* vel */2][/* x */0]) * 0.25), -6);
                return /* () */0;
              } else {
                return 0;
              }
          case 3 : 
              if (!player$1[/* jumping */4] && player$1[/* grounded */5]) {
                player$1[/* crouch */10] = /* true */1;
                return /* () */0;
              } else {
                return 0;
              }
          
        }
      }, keys);
  var v = player[/* vel */2][/* x */0] * 0.9;
  var vel_damped = Math.abs(v) < 0.1 ? 0 : v;
  player[/* vel */2][/* x */0] = vel_damped;
  var pl_typ = player[/* health */9] <= 1 ? /* SmallM */1 : /* BigM */0;
  if (!prev_jumping && player[/* jumping */4]) {
    return /* Some */[/* tuple */[
              pl_typ,
              make$1(/* SPlayer */__(0, [
                      pl_typ,
                      /* Jumping */1
                    ]), player[/* dir */6], context)
            ]];
  } else if (!eq_dir_1d(prev_dir, player[/* dir */6]) || prev_vx === 0 && Math.abs(player[/* vel */2][/* x */0]) > 0 && !player[/* jumping */4]) {
    return /* Some */[/* tuple */[
              pl_typ,
              make$1(/* SPlayer */__(0, [
                      pl_typ,
                      /* Running */2
                    ]), player[/* dir */6], context)
            ]];
  } else if (!eq_dir_1d(prev_dir, player[/* dir */6]) && player[/* jumping */4] && prev_jumping) {
    return /* Some */[/* tuple */[
              pl_typ,
              make$1(/* SPlayer */__(0, [
                      pl_typ,
                      /* Jumping */1
                    ]), player[/* dir */6], context)
            ]];
  } else if (player[/* vel */2][/* y */1] === 0 && player[/* crouch */10]) {
    return /* Some */[/* tuple */[
              pl_typ,
              make$1(/* SPlayer */__(0, [
                      pl_typ,
                      /* Crouching */3
                    ]), player[/* dir */6], context)
            ]];
  } else if (player[/* vel */2][/* y */1] === 0 && player[/* vel */2][/* x */0] === 0) {
    return /* Some */[/* tuple */[
              pl_typ,
              make$1(/* SPlayer */__(0, [
                      pl_typ,
                      /* Standing */0
                    ]), player[/* dir */6], context)
            ]];
  } else {
    return /* None */0;
  }
}

function update_vel(obj) {
  if (obj[/* grounded */5]) {
    obj[/* vel */2][/* y */1] = 0;
    return /* () */0;
  } else if (obj[/* params */0][/* has_gravity */0]) {
    obj[/* vel */2][/* y */1] = min(obj[/* vel */2][/* y */1] + 0.2 + Math.abs(obj[/* vel */2][/* y */1]) * 0.01, 4.5);
    return /* () */0;
  } else {
    return 0;
  }
}

function update_pos(obj) {
  obj[/* pos */1][/* x */0] = obj[/* vel */2][/* x */0] + obj[/* pos */1][/* x */0];
  if (obj[/* params */0][/* has_gravity */0]) {
    obj[/* pos */1][/* y */1] = obj[/* vel */2][/* y */1] + obj[/* pos */1][/* y */1];
    return /* () */0;
  } else {
    return 0;
  }
}

function process_obj(obj, mapy) {
  update_vel(obj);
  update_pos(obj);
  if (obj[/* pos */1][/* y */1] > mapy) {
    obj[/* kill */8] = /* true */1;
    return /* () */0;
  } else {
    return 0;
  }
}

function collide_block($staropt$star, dir, obj) {
  var check_x = $staropt$star ? $staropt$star[0] : /* true */1;
  if (dir !== 1) {
    if (dir !== 0) {
      if (check_x) {
        obj[/* vel */2][/* x */0] = 0;
        return /* () */0;
      } else {
        return 0;
      }
    } else {
      obj[/* vel */2][/* y */1] = -0.001;
      return /* () */0;
    }
  } else {
    obj[/* vel */2][/* y */1] = 0;
    obj[/* grounded */5] = /* true */1;
    obj[/* jumping */4] = /* false */0;
    return /* () */0;
  }
}

function opposite_dir(dir) {
  if (dir !== 0) {
    return /* Left */0;
  } else {
    return /* Right */1;
  }
}

function reverse_left_right(obj) {
  obj[/* vel */2][/* x */0] = -obj[/* vel */2][/* x */0];
  obj[/* dir */6] = opposite_dir(obj[/* dir */6]);
  return /* () */0;
}

function evolve_enemy(player_dir, typ, spr, obj, context) {
  var exit$$1 = 0;
  switch (typ) {
    case 0 : 
        obj[/* kill */8] = /* true */1;
        return /* None */0;
    case 1 : 
        var match = make$$1(/* None */0, /* Some */[obj[/* dir */6]], /* SEnemy */__(1, [/* GKoopaShell */3]), context, /* tuple */[
              obj[/* pos */1][/* x */0],
              obj[/* pos */1][/* y */1]
            ]);
        var new_obj = match[1];
        var new_spr = match[0];
        normalize_pos(new_obj[/* pos */1], spr[/* params */0], new_spr[/* params */0]);
        return /* Some */[/* Enemy */__(1, [
                    /* GKoopaShell */3,
                    new_spr,
                    new_obj
                  ])];
    case 2 : 
        var match$1 = make$$1(/* None */0, /* Some */[obj[/* dir */6]], /* SEnemy */__(1, [/* RKoopaShell */4]), context, /* tuple */[
              obj[/* pos */1][/* x */0],
              obj[/* pos */1][/* y */1]
            ]);
        var new_obj$1 = match$1[1];
        var new_spr$1 = match$1[0];
        normalize_pos(new_obj$1[/* pos */1], spr[/* params */0], new_spr$1[/* params */0]);
        return /* Some */[/* Enemy */__(1, [
                    /* RKoopaShell */4,
                    new_spr$1,
                    new_obj$1
                  ])];
    case 3 : 
    case 4 : 
        exit$$1 = 1;
        break;
    
  }
  if (exit$$1 === 1) {
    obj[/* dir */6] = player_dir;
    if (obj[/* vel */2][/* x */0] !== 0) {
      obj[/* vel */2][/* x */0] = 0;
    } else {
      set_vel_to_speed(obj);
    }
    return /* None */0;
  }
  
}

function rev_dir(o, t, s) {
  reverse_left_right(o);
  var old_params = s[/* params */0];
  transform_enemy(t, s, o[/* dir */6]);
  return normalize_pos(o[/* pos */1], old_params, s[/* params */0]);
}

function dec_health(obj) {
  var health = obj[/* health */9] - 1 | 0;
  if (health) {
    if (obj[/* invuln */7]) {
      return 0;
    } else {
      obj[/* health */9] = health;
      return /* () */0;
    }
  } else {
    obj[/* kill */8] = /* true */1;
    return /* () */0;
  }
}

function evolve_block(obj, context) {
  dec_health(obj);
  var match = make$$1(/* None */0, /* None */0, /* SBlock */__(3, [/* QBlockUsed */0]), context, /* tuple */[
        obj[/* pos */1][/* x */0],
        obj[/* pos */1][/* y */1]
      ]);
  return /* Block */__(3, [
            /* QBlockUsed */0,
            match[0],
            match[1]
          ]);
}

function spawn_above(player_dir, obj, typ, context) {
  var item = spawn(/* SItem */__(2, [typ]), context, /* tuple */[
        obj[/* pos */1][/* x */0],
        obj[/* pos */1][/* y */1]
      ]);
  var item_obj = item[2];
  item_obj[/* pos */1][/* y */1] = item_obj[/* pos */1][/* y */1] - item[1][/* params */0][/* frame_size */3][1];
  item_obj[/* dir */6] = opposite_dir(player_dir);
  set_vel_to_speed(item_obj);
  return item;
}

function get_aabb(obj) {
  var spr = obj[1][/* params */0];
  var obj$1 = obj[2];
  var match = spr[/* bbox_offset */5];
  var match_000 = obj$1[/* pos */1][/* x */0] + match[0];
  var match_001 = obj$1[/* pos */1][/* y */1] + match[1];
  var match$1 = spr[/* bbox_size */6];
  var sy = match$1[1];
  var sx = match$1[0];
  return /* record */[
          /* center : float array */[
            match_000 + sx / 2,
            match_001 + sy / 2
          ],
          /* half : float array */[
            sx / 2,
            sy / 2
          ]
        ];
}

function col_bypass(c1, c2) {
  var o1 = c1[2];
  var o2 = c2[2];
  var ctypes;
  switch (c1.tag | 0) {
    case 0 : 
        ctypes = c2.tag === 1 && c1[2][/* invuln */7] > 0 ? /* true */1 : /* false */0;
        break;
    case 1 : 
        ctypes = c2.tag === 2 ? /* true */1 : /* false */0;
        break;
    case 2 : 
        switch (c2.tag | 0) {
          case 1 : 
          case 2 : 
              ctypes = /* true */1;
              break;
          case 0 : 
          case 3 : 
              ctypes = /* false */0;
              break;
          
        }
        break;
    case 3 : 
        ctypes = /* false */0;
        break;
    
  }
  if (o1[/* kill */8] || o2[/* kill */8]) {
    return /* true */1;
  } else {
    return ctypes;
  }
}

function check_collision(c1, c2) {
  var b1 = get_aabb(c1);
  var b2 = get_aabb(c2);
  var o1 = c1[2];
  if (col_bypass(c1, c2)) {
    return /* None */0;
  } else {
    var vx = b1[/* center */0][/* x */0] - b2[/* center */0][/* x */0];
    var vy = b1[/* center */0][/* y */1] - b2[/* center */0][/* y */1];
    var hwidths = b1[/* half */1][/* x */0] + b2[/* half */1][/* x */0];
    var hheights = b1[/* half */1][/* y */1] + b2[/* half */1][/* y */1];
    if (Math.abs(vx) < hwidths && Math.abs(vy) < hheights) {
      var ox = hwidths - Math.abs(vx);
      var oy = hheights - Math.abs(vy);
      if (ox >= oy) {
        if (vy > 0) {
          o1[/* pos */1][/* y */1] = o1[/* pos */1][/* y */1] + oy;
          return /* Some */[/* North */0];
        } else {
          o1[/* pos */1][/* y */1] = o1[/* pos */1][/* y */1] - oy;
          return /* Some */[/* South */1];
        }
      } else if (vx > 0) {
        o1[/* pos */1][/* x */0] = o1[/* pos */1][/* x */0] + ox;
        return /* Some */[/* West */3];
      } else {
        o1[/* pos */1][/* x */0] = o1[/* pos */1][/* x */0] - ox;
        return /* Some */[/* East */2];
      }
    } else {
      return /* None */0;
    }
  }
}

function kill(collid, ctx) {
  switch (collid.tag | 0) {
    case 0 : 
        return /* [] */0;
    case 1 : 
        var o = collid[2];
        var pos_000 = o[/* pos */1][/* x */0];
        var pos_001 = o[/* pos */1][/* y */1];
        var pos = /* tuple */[
          pos_000,
          pos_001
        ];
        var score = o[/* score */11] > 0 ? /* :: */[
            make_score(o[/* score */11], pos, ctx),
            /* [] */0
          ] : /* [] */0;
        var remains = collid[0] !== 0 ? /* [] */0 : /* :: */[
            make$2(/* None */0, /* None */0, /* GoombaSquish */0, pos, ctx),
            /* [] */0
          ];
        return $at(score, remains);
    case 2 : 
        var o$1 = collid[2];
        if (collid[0] !== 0) {
          return /* [] */0;
        } else {
          return /* :: */[
                  make_score(o$1[/* score */11], /* tuple */[
                        o$1[/* pos */1][/* x */0],
                        o$1[/* pos */1][/* y */1]
                      ], ctx),
                  /* [] */0
                ];
        }
    case 3 : 
        var o$2 = collid[2];
        var t = collid[0];
        if (typeof t === "number") {
          if (t !== 1) {
            return /* [] */0;
          } else {
            var pos_000$1 = o$2[/* pos */1][/* x */0];
            var pos_001$1 = o$2[/* pos */1][/* y */1];
            var pos$1 = /* tuple */[
              pos_000$1,
              pos_001$1
            ];
            var p1 = make$2(/* Some */[/* tuple */[
                    -5,
                    -5
                  ]], /* Some */[/* tuple */[
                    0,
                    0.2
                  ]], /* BrickChunkL */1, pos$1, ctx);
            var p2 = make$2(/* Some */[/* tuple */[
                    -3,
                    -4
                  ]], /* Some */[/* tuple */[
                    0,
                    0.2
                  ]], /* BrickChunkL */1, pos$1, ctx);
            var p3 = make$2(/* Some */[/* tuple */[
                    3,
                    -4
                  ]], /* Some */[/* tuple */[
                    0,
                    0.2
                  ]], /* BrickChunkR */2, pos$1, ctx);
            var p4 = make$2(/* Some */[/* tuple */[
                    5,
                    -5
                  ]], /* Some */[/* tuple */[
                    0,
                    0.2
                  ]], /* BrickChunkR */2, pos$1, ctx);
            return /* :: */[
                    p1,
                    /* :: */[
                      p2,
                      /* :: */[
                        p3,
                        /* :: */[
                          p4,
                          /* [] */0
                        ]
                      ]
                    ]
                  ];
          }
        } else {
          return /* [] */0;
        }
        break;
    
  }
}

var invuln = 60;

var dampen_jump = 4;


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function make$3(param, param$1) {
  return /* record */[
          /* pos : float array */[
            0,
            0
          ],
          /* v_dim : float array */[
            param[0],
            param[1]
          ],
          /* m_dim : float array */[
            param$1[0],
            param$1[1]
          ]
        ];
}

function calc_viewport_point(cc, vc, mc) {
  var vc_half = vc / 2;
  return min_float$1(max_float$1(cc - vc_half, 0), min_float$1(mc - vc, Math.abs(cc - vc_half)));
}

function in_viewport(v, pos) {
  var match_000 = v[/* pos */0][/* x */0] - 32;
  var match_001 = v[/* pos */0][/* x */0] + v[/* v_dim */1][/* x */0];
  var match_000$1 = v[/* pos */0][/* y */1] - 32;
  var match_001$1 = v[/* pos */0][/* y */1] + v[/* v_dim */1][/* y */1];
  var match_000$2 = pos[/* x */0];
  var match_001$2 = pos[/* y */1];
  var y = match_001$2;
  var x = match_000$2;
  if (x >= match_000 && x <= match_001 && y >= match_000$1) {
    return +(y <= match_001$1);
  } else {
    return /* false */0;
  }
}

function out_of_viewport_below(v, y) {
  var v_max_y = v[/* pos */0][/* y */1] + v[/* v_dim */1][/* y */1];
  return +(y >= v_max_y);
}

function coord_to_viewport(viewport, coord) {
  return /* float array */[
          coord[/* x */0] - viewport[/* pos */0][/* x */0],
          coord[/* y */1] - viewport[/* pos */0][/* y */1]
        ];
}

function update(vpt, ctr) {
  var new_x = calc_viewport_point(ctr[/* x */0], vpt[/* v_dim */1][/* x */0], vpt[/* m_dim */2][/* x */0]);
  var new_y = calc_viewport_point(ctr[/* y */1], vpt[/* v_dim */1][/* y */1], vpt[/* m_dim */2][/* y */1]);
  var pos = /* float array */[
    new_x,
    new_y
  ];
  return /* record */[
          /* pos */pos,
          /* v_dim */vpt[/* v_dim */1],
          /* m_dim */vpt[/* m_dim */2]
        ];
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
var pressed_keys = /* record */[
  /* left : false */0,
  /* right : false */0,
  /* up : false */0,
  /* down : false */0,
  /* bbox */0
];

var collid_objs = [/* [] */0];

var particles = [/* [] */0];

var last_time = [0];

function calc_fps(t0, t1) {
  var delta = (t1 - t0) / 1000;
  return 1 / delta;
}

function update_score(state, i) {
  state[/* score */4] = state[/* score */4] + i | 0;
  return /* () */0;
}

function process_collision(dir, c1, c2, state) {
  var context = state[/* ctx */1];
  var exit$$1 = 0;
  var s1;
  var o1;
  var typ;
  var s2;
  var o2;
  var s1$1;
  var o1$1;
  var t2;
  var s2$1;
  var o2$1;
  var o1$2;
  var t2$1;
  var o2$2;
  switch (c1.tag | 0) {
    case 0 : 
        var o1$3 = c1[2];
        var s1$2 = c1[1];
        switch (c2.tag | 0) {
          case 0 : 
              return /* tuple */[
                      /* None */0,
                      /* None */0
                    ];
          case 1 : 
              var o2$3 = c2[2];
              var s2$2 = c2[1];
              var typ$1 = c2[0];
              if (dir !== 1) {
                s1$1 = s1$2;
                o1$1 = o1$3;
                t2 = typ$1;
                s2$1 = s2$2;
                o2$1 = o2$3;
                exit$$1 = 2;
              } else {
                s1 = s1$2;
                o1 = o1$3;
                typ = typ$1;
                s2 = s2$2;
                o2 = o2$3;
                exit$$1 = 1;
              }
              break;
          case 2 : 
              o1$2 = o1$3;
              t2$1 = c2[0];
              o2$2 = c2[2];
              exit$$1 = 3;
              break;
          case 3 : 
              var o2$4 = c2[2];
              var t = c2[0];
              if (dir !== 0) {
                var exit$1 = 0;
                if (typeof t === "number") {
                  if (t !== 4) {
                    exit$1 = 4;
                  } else {
                    game_win(state[/* ctx */1]);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  }
                } else {
                  exit$1 = 4;
                }
                if (exit$1 === 4) {
                  if (dir !== 1) {
                    collide_block(/* None */0, dir, o1$3);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  } else {
                    state[/* multiplier */6] = 1;
                    collide_block(/* None */0, dir, o1$3);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  }
                }
                
              } else if (typeof t === "number") {
                if (t !== 1) {
                  if (t !== 4) {
                    collide_block(/* None */0, dir, o1$3);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  } else {
                    game_win(state[/* ctx */1]);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  }
                } else if (c1[0]) {
                  collide_block(/* None */0, dir, o1$3);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                } else {
                  collide_block(/* None */0, dir, o1$3);
                  dec_health(o2$4);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                }
              } else {
                var updated_block = evolve_block(o2$4, context);
                var spawned_item = spawn_above(o1$3[/* dir */6], o2$4, t[0], context);
                collide_block(/* None */0, dir, o1$3);
                return /* tuple */[
                        /* Some */[spawned_item],
                        /* Some */[updated_block]
                      ];
              }
              break;
          
        }
        break;
    case 1 : 
        var o1$4 = c1[2];
        var s1$3 = c1[1];
        var t1 = c1[0];
        switch (c2.tag | 0) {
          case 0 : 
              var o1$5 = c2[2];
              var s1$4 = c2[1];
              if (dir !== 0) {
                s1$1 = s1$4;
                o1$1 = o1$5;
                t2 = t1;
                s2$1 = s1$3;
                o2$1 = o1$4;
                exit$$1 = 2;
              } else {
                s1 = s1$4;
                o1 = o1$5;
                typ = t1;
                s2 = s1$3;
                o2 = o1$4;
                exit$$1 = 1;
              }
              break;
          case 1 : 
              var t1$1 = t1;
              var s1$5 = s1$3;
              var o1$6 = o1$4;
              var t2$2 = c2[0];
              var s2$3 = c2[1];
              var o2$5 = c2[2];
              var dir$1 = dir;
              var exit$2 = 0;
              if (t1$1 !== 3) {
                if (t1$1 >= 4) {
                  if (t2$2 >= 3) {
                    dec_health(o1$6);
                    dec_health(o2$5);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  } else {
                    exit$2 = 1;
                  }
                } else if (t2$2 >= 3) {
                  if (o2$5[/* vel */2][/* x */0] === 0) {
                    rev_dir(o1$6, t1$1, s1$5);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  } else {
                    dec_health(o1$6);
                    return /* tuple */[
                            /* None */0,
                            /* None */0
                          ];
                  }
                } else if (dir$1 >= 2) {
                  rev_dir(o1$6, t1$1, s1$5);
                  rev_dir(o2$5, t2$2, s2$3);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                } else {
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                }
              } else if (t2$2 >= 3) {
                dec_health(o1$6);
                dec_health(o2$5);
                return /* tuple */[
                        /* None */0,
                        /* None */0
                      ];
              } else {
                exit$2 = 1;
              }
              if (exit$2 === 1) {
                if (o1$6[/* vel */2][/* x */0] === 0) {
                  rev_dir(o2$5, t2$2, s2$3);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                } else {
                  dec_health(o2$5);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                }
              }
              case 2 : 
              return /* tuple */[
                      /* None */0,
                      /* None */0
                    ];
          case 3 : 
              var o2$6 = c2[2];
              var t2$3 = c2[0];
              if (dir >= 2) {
                if (t1 >= 3) {
                  if (typeof t2$3 === "number") {
                    if (t2$3 !== 1) {
                      rev_dir(o1$4, t1, s1$3);
                      return /* tuple */[
                              /* None */0,
                              /* None */0
                            ];
                    } else {
                      dec_health(o2$6);
                      reverse_left_right(o1$4);
                      return /* tuple */[
                              /* None */0,
                              /* None */0
                            ];
                    }
                  } else {
                    var updated_block$1 = evolve_block(o2$6, context);
                    var spawned_item$1 = spawn_above(o1$4[/* dir */6], o2$6, t2$3[0], context);
                    rev_dir(o1$4, t1, s1$3);
                    return /* tuple */[
                            /* Some */[updated_block$1],
                            /* Some */[spawned_item$1]
                          ];
                  }
                } else {
                  rev_dir(o1$4, t1, s1$3);
                  return /* tuple */[
                          /* None */0,
                          /* None */0
                        ];
                }
              } else {
                collide_block(/* None */0, dir, o1$4);
                return /* tuple */[
                        /* None */0,
                        /* None */0
                      ];
              }
              break;
          
        }
        break;
    case 2 : 
        var o2$7 = c1[2];
        switch (c2.tag | 0) {
          case 0 : 
              o1$2 = c2[2];
              t2$1 = c1[0];
              o2$2 = o2$7;
              exit$$1 = 3;
              break;
          case 1 : 
          case 2 : 
              return /* tuple */[
                      /* None */0,
                      /* None */0
                    ];
          case 3 : 
              if (dir >= 2) {
                reverse_left_right(o2$7);
                return /* tuple */[
                        /* None */0,
                        /* None */0
                      ];
              } else {
                collide_block(/* None */0, dir, o2$7);
                return /* tuple */[
                        /* None */0,
                        /* None */0
                      ];
              }
          
        }
        break;
    case 3 : 
        return /* tuple */[
                /* None */0,
                /* None */0
              ];
    
  }
  switch (exit$$1) {
    case 1 : 
        var o1$7 = o1;
        var typ$2 = typ;
        var s2$4 = s2;
        var o2$8 = o2;
        var state$1 = state;
        var context$1 = context;
        o1$7[/* invuln */7] = 10;
        o1$7[/* jumping */4] = /* false */0;
        o1$7[/* grounded */5] = /* true */1;
        if (typ$2 >= 3) {
          var r2 = evolve_enemy(o1$7[/* dir */6], typ$2, s2$4, o2$8, context$1);
          o1$7[/* vel */2][/* y */1] = -dampen_jump;
          o1$7[/* pos */1][/* y */1] = o1$7[/* pos */1][/* y */1] - 5;
          return /* tuple */[
                  /* None */0,
                  r2
                ];
        } else {
          dec_health(o2$8);
          o1$7[/* vel */2][/* y */1] = -dampen_jump;
          if (state$1[/* multiplier */6] === 8) {
            update_score(state$1, 800);
            o2$8[/* score */11] = 800;
            return /* tuple */[
                    /* None */0,
                    evolve_enemy(o1$7[/* dir */6], typ$2, s2$4, o2$8, context$1)
                  ];
          } else {
            var score = imul(100, state$1[/* multiplier */6]);
            update_score(state$1, score);
            o2$8[/* score */11] = score;
            state$1[/* multiplier */6] = (state$1[/* multiplier */6] << 1);
            return /* tuple */[
                    /* None */0,
                    evolve_enemy(o1$7[/* dir */6], typ$2, s2$4, o2$8, context$1)
                  ];
          }
        }
    case 2 : 
        var o1$8 = o1$1;
        var t2$4 = t2;
        var s2$5 = s2$1;
        var o2$9 = o2$1;
        var context$2 = context;
        if (t2$4 >= 3) {
          var r2$1 = o2$9[/* vel */2][/* x */0] === 0 ? evolve_enemy(o1$8[/* dir */6], t2$4, s2$5, o2$9, context$2) : (dec_health(o1$8), o1$8[/* invuln */7] = invuln, /* None */0);
          return /* tuple */[
                  /* None */0,
                  r2$1
                ];
        } else {
          dec_health(o1$8);
          o1$8[/* invuln */7] = invuln;
          return /* tuple */[
                  /* None */0,
                  /* None */0
                ];
        }
    case 3 : 
        if (t2$1 !== 0) {
          if (t2$1 >= 3) {
            state[/* coins */5] = state[/* coins */5] + 1 | 0;
            dec_health(o2$2);
            update_score(state, 100);
            return /* tuple */[
                    /* None */0,
                    /* None */0
                  ];
          } else {
            dec_health(o2$2);
            update_score(state, 1000);
            return /* tuple */[
                    /* None */0,
                    /* None */0
                  ];
          }
        } else {
          dec_health(o2$2);
          if (o1$2[/* health */9] !== 2) {
            o1$2[/* health */9] = o1$2[/* health */9] + 1 | 0;
          }
          o1$2[/* vel */2][/* x */0] = 0;
          o1$2[/* vel */2][/* y */1] = 0;
          update_score(state, 1000);
          o2$2[/* score */11] = 1000;
          return /* tuple */[
                  /* None */0,
                  /* None */0
                ];
        }
        break;
    
  }
}

function broad_phase(collid, all_collids, state) {
  var obj = get_obj(collid);
  return filter(function () {
                if (in_viewport(state[/* vpt */2], obj[/* pos */1]) || is_player(collid)) {
                  return /* true */1;
                } else {
                  return out_of_viewport_below(state[/* vpt */2], obj[/* pos */1][/* y */1]);
                }
              })(all_collids);
}

function check_collisions(collid, all_collids, state) {
  if (collid.tag === 3) {
    return /* [] */0;
  } else {
    var broad = broad_phase(collid, all_collids, state);
    var c = collid;
    var cs = broad;
    var state$1 = state;
    var c$1 = c;
    var _cs = cs;
    var state$2 = state$1;
    var _acc = /* [] */0;
    while(true) {
      var acc = _acc;
      var cs$1 = _cs;
      if (cs$1) {
        var h = cs$1[0];
        var c_obj = get_obj(c$1);
        var new_objs;
        if (equals(c$1, h)) {
          new_objs = /* tuple */[
            /* None */0,
            /* None */0
          ];
        } else {
          var match = check_collision(c$1, h);
          new_objs = match ? (
              get_obj(h)[/* id */3] !== c_obj[/* id */3] ? process_collision(match[0], c$1, h, state$2) : /* tuple */[
                  /* None */0,
                  /* None */0
                ]
            ) : /* tuple */[
              /* None */0,
              /* None */0
            ];
        }
        var match$1 = new_objs[0];
        var acc$1;
        if (match$1) {
          var match$2 = new_objs[1];
          var o = match$1[0];
          acc$1 = match$2 ? /* :: */[
              o,
              /* :: */[
                match$2[0],
                acc
              ]
            ] : /* :: */[
              o,
              acc
            ];
        } else {
          var match$3 = new_objs[1];
          acc$1 = match$3 ? /* :: */[
              match$3[0],
              acc
            ] : acc;
        }
        _acc = acc$1;
        _cs = cs$1[1];
        continue ;
        
      } else {
        return acc;
      }
    }
  }
}

function update_collidable(state, collid, all_collids) {
  var obj = get_obj(collid);
  var spr = get_sprite(collid);
  obj[/* invuln */7] = obj[/* invuln */7] > 0 ? obj[/* invuln */7] - 1 | 0 : 0;
  var viewport_filter = in_viewport(state[/* vpt */2], obj[/* pos */1]) || is_player(collid) || out_of_viewport_below(state[/* vpt */2], obj[/* pos */1][/* y */1]);
  if (!obj[/* kill */8] && viewport_filter) {
    obj[/* grounded */5] = /* false */0;
    process_obj(obj, state[/* map */3]);
    var evolved = check_collisions(collid, all_collids, state);
    var vpt_adj_xy = coord_to_viewport(state[/* vpt */2], obj[/* pos */1]);
    render(spr, /* tuple */[
          vpt_adj_xy[/* x */0],
          vpt_adj_xy[/* y */1]
        ]);
    if (pressed_keys[/* bbox */4] === 1) {
      render_bbox(spr, /* tuple */[
            vpt_adj_xy[/* x */0],
            vpt_adj_xy[/* y */1]
          ]);
    }
    if (obj[/* vel */2][/* x */0] !== 0 || !is_enemy(collid)) {
      update_animation(spr);
    }
    return evolved;
  } else {
    return /* [] */0;
  }
}

function translate_keys() {
  var ctrls_000 = /* tuple */[
    pressed_keys[/* left */0],
    /* CLeft */0
  ];
  var ctrls_001 = /* :: */[
    /* tuple */[
      pressed_keys[/* right */1],
      /* CRight */1
    ],
    /* :: */[
      /* tuple */[
        pressed_keys[/* up */2],
        /* CUp */2
      ],
      /* :: */[
        /* tuple */[
          pressed_keys[/* down */3],
          /* CDown */3
        ],
        /* [] */0
      ]
    ]
  ];
  var ctrls = /* :: */[
    ctrls_000,
    ctrls_001
  ];
  return fold_left(function (a, x) {
              if (x[0]) {
                return /* :: */[
                        x[1],
                        a
                      ];
              } else {
                return a;
              }
            }, /* [] */0, ctrls);
}

function run_update_collid(state, collid, all_collids) {
  if (collid.tag) {
    var obj = get_obj(collid);
    var evolved = update_collidable(state, collid, all_collids);
    if (!obj[/* kill */8]) {
      collid_objs[0] = /* :: */[
        collid,
        $at(collid_objs[0], evolved)
      ];
    }
    var new_parts = obj[/* kill */8] ? kill(collid, state[/* ctx */1]) : /* [] */0;
    particles[0] = $at(particles[0], new_parts);
    return collid;
  } else {
    var o = collid[2];
    var keys = translate_keys(/* () */0);
    o[/* crouch */10] = /* false */0;
    var match = update_player(o, keys, state[/* ctx */1]);
    var player;
    if (match) {
      var match$1 = match[0];
      var new_spr = match$1[1];
      normalize_pos(o[/* pos */1], collid[1][/* params */0], new_spr[/* params */0]);
      player = /* Player */__(0, [
          match$1[0],
          new_spr,
          o
        ]);
    } else {
      player = collid;
    }
    var evolved$1 = update_collidable(state, player, all_collids);
    collid_objs[0] = $at(collid_objs[0], evolved$1);
    return player;
  }
}

function update_loop(canvas, param, map_dim) {
  var player = param[0];
  var ctx = canvas.getContext("2d");
  var cwidth = canvas.width / 1;
  var cheight = canvas.height / 1;
  var viewport = make$3(/* tuple */[
        cwidth,
        cheight
      ], map_dim);
  var state = /* record */[
    /* bgd */make_bgd(ctx),
    /* ctx */ctx,
    /* vpt */update(viewport, get_obj(player)[/* pos */1]),
    /* map */map_dim[1],
    /* score */0,
    /* coins */0,
    /* multiplier */1,
    /* game_over : false */0
  ];
  state[/* ctx */1].scale(1, 1);
  var update_helper = function (time, state, player, objs, parts) {
    if (state[/* game_over */7] === /* true */1) {
      return game_win(state[/* ctx */1]);
    } else {
      collid_objs[0] = /* [] */0;
      particles[0] = /* [] */0;
      var fps$$1 = calc_fps(last_time[0], time);
      last_time[0] = time;
      clear_canvas(canvas);
      var vpos_x_int = state[/* vpt */2][/* pos */0][/* x */0] / 5 | 0;
      var bgd_width = state[/* bgd */0][/* params */0][/* frame_size */3][0] | 0;
      draw_bgd(state[/* bgd */0], mod_(vpos_x_int, bgd_width));
      var player$1 = run_update_collid(state, player, objs);
      if (get_obj(player$1)[/* kill */8] === /* true */1) {
        return game_loss(state[/* ctx */1]);
      } else {
        var newrecord = state.slice();
        newrecord[/* vpt */2] = update(state[/* vpt */2], get_obj(player$1)[/* pos */1]);
        iter(function (obj) {
              run_update_collid(newrecord, obj, objs);
              return /* () */0;
            }, objs);
        iter(function (part) {
              var state = newrecord;
              var part$1 = part;
              $$process(part$1);
              var x = part$1[/* pos */2][/* x */0] - state[/* vpt */2][/* pos */0][/* x */0];
              var y = part$1[/* pos */2][/* y */1] - state[/* vpt */2][/* pos */0][/* y */1];
              render(part$1[/* params */0][/* sprite */0], /* tuple */[
                    x,
                    y
                  ]);
              if (part$1[/* kill */5]) {
                return 0;
              } else {
                particles[0] = /* :: */[
                  part$1,
                  particles[0]
                ];
                return /* () */0;
              }
            }, parts);
        fps(canvas, fps$$1);
        hud(canvas, newrecord[/* score */4], newrecord[/* coins */5]);
        requestAnimationFrame(function (t) {
              return update_helper(t, newrecord, player$1, collid_objs[0], particles[0]);
            });
        return /* () */0;
      }
    }
  };
  return update_helper(0, state, player, param[1], /* [] */0);
}

function keydown(evt) {
  var match = evt.keyCode;
  if (match >= 41) {
    var switcher = match - 65 | 0;
    if (!(switcher > 22 || switcher < 0)) {
      switch (switcher) {
        case 0 : 
            pressed_keys[/* left */0] = /* true */1;
            break;
        case 1 : 
            pressed_keys[/* bbox */4] = (pressed_keys[/* bbox */4] + 1 | 0) % 2;
            break;
        case 3 : 
            pressed_keys[/* right */1] = /* true */1;
            break;
        case 18 : 
            pressed_keys[/* down */3] = /* true */1;
            break;
        case 2 : 
        case 4 : 
        case 5 : 
        case 6 : 
        case 7 : 
        case 8 : 
        case 9 : 
        case 10 : 
        case 11 : 
        case 12 : 
        case 13 : 
        case 14 : 
        case 15 : 
        case 16 : 
        case 17 : 
        case 19 : 
        case 20 : 
        case 21 : 
            break;
        case 22 : 
            pressed_keys[/* up */2] = /* true */1;
            break;
        
      }
    }
    
  } else if (match >= 32) {
    switch (match - 32 | 0) {
      case 1 : 
      case 2 : 
      case 3 : 
      case 4 : 
          break;
      case 5 : 
          pressed_keys[/* left */0] = /* true */1;
          break;
      case 0 : 
      case 6 : 
          pressed_keys[/* up */2] = /* true */1;
          break;
      case 7 : 
          pressed_keys[/* right */1] = /* true */1;
          break;
      case 8 : 
          pressed_keys[/* down */3] = /* true */1;
          break;
      
    }
  }
  return true;
}

function keyup(evt) {
  var match = evt.keyCode;
  if (match >= 68) {
    if (match !== 83) {
      if (match !== 87) {
        if (match >= 69) {
          
        } else {
          pressed_keys[/* right */1] = /* false */0;
        }
      } else {
        pressed_keys[/* up */2] = /* false */0;
      }
    } else {
      pressed_keys[/* down */3] = /* false */0;
    }
  } else if (match >= 41) {
    if (match === 65) {
      pressed_keys[/* left */0] = /* false */0;
    }
    
  } else if (match >= 32) {
    switch (match - 32 | 0) {
      case 1 : 
      case 2 : 
      case 3 : 
      case 4 : 
          break;
      case 5 : 
          pressed_keys[/* left */0] = /* false */0;
          break;
      case 0 : 
      case 6 : 
          pressed_keys[/* up */2] = /* false */0;
          break;
      case 7 : 
          pressed_keys[/* right */1] = /* false */0;
          break;
      case 8 : 
          pressed_keys[/* down */3] = /* false */0;
          break;
      
    }
  }
  return true;
}


/* Draw Not a pure module */

function floor_int(f) {
  if (f > max_int) {
    return max_int;
  } else if (f < min_int) {
    return min_int;
  } else {
    return Math.floor(f);
  }
}

function random_int(min$$1, max$$1) {
  return floor_int(Math.random() * (max$$1 - min$$1 | 0)) + min$$1 | 0;
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
function mem_loc(checkloc, _loclist) {
  while(true) {
    var loclist = _loclist;
    if (loclist) {
      if (eq_checkloc(checkloc, loclist[0][1])) {
        return /* true */1;
      } else {
        _loclist = loclist[1];
        continue ;
        
      }
    } else {
      return /* false */0;
    }
  }
}

function convert_list(lst) {
  if (lst) {
    var h = lst[0];
    return $at(/* :: */[
                /* tuple */[
                  h[0],
                  /* tuple */[
                    h[1][0] * 16,
                    h[1][1] * 16
                  ]
                ],
                /* [] */0
              ], convert_list(lst[1]));
  } else {
    return /* [] */0;
  }
}

function choose_enemy_typ(typ) {
  if (typ > 2 || typ < 0) {
    return failwith("Shouldn't reach here");
  } else {
    switch (typ) {
      case 0 : 
          return /* RKoopa */2;
      case 1 : 
          return /* GKoopa */1;
      case 2 : 
          return /* Goomba */0;
      
    }
  }
}

function choose_sblock_typ(typ) {
  if (typ > 4 || typ < 0) {
    return failwith("Shouldn't reach here");
  } else {
    switch (typ) {
      case 0 : 
          return /* Brick */1;
      case 1 : 
          return /* UnBBlock */2;
      case 2 : 
          return /* Cloud */3;
      case 3 : 
          return /* QBlock */[/* Mushroom */0];
      case 4 : 
          return /* Ground */5;
      
    }
  }
}

function avoid_overlap(_lst, currentLst) {
  while(true) {
    var lst = _lst;
    if (lst) {
      var t = lst[1];
      var h = lst[0];
      if (mem_loc(h[1], currentLst)) {
        _lst = t;
        continue ;
        
      } else {
        return $at(/* :: */[
                    h,
                    /* [] */0
                  ], avoid_overlap(t, currentLst));
      }
    } else {
      return /* [] */0;
    }
  }
}

function trim_edges(_lst, blockw, blockh) {
  while(true) {
    var lst = _lst;
    if (lst) {
      var t = lst[1];
      var h = lst[0];
      var cx = h[1][0];
      var cy = h[1][1];
      var pixx = blockw * 16;
      var pixy = blockh * 16;
      if (cx < 128 || pixx - cx < 528 || cy === 0 || pixy - cy < 48) {
        _lst = t;
        continue ;
        
      } else {
        return $at(/* :: */[
                    h,
                    /* [] */0
                  ], trim_edges(t, blockw, blockh));
      }
    } else {
      return /* [] */0;
    }
  }
}

function generate_clouds(cbx, cby, typ, num) {
  if (num) {
    return $at(/* :: */[
                /* tuple */[
                  typ,
                  /* tuple */[
                    cbx,
                    cby
                  ]
                ],
                /* [] */0
              ], generate_clouds(cbx + 1, cby, typ, num - 1 | 0));
  } else {
    return /* [] */0;
  }
}

function generate_coins(_block_coord) {
  while(true) {
    var block_coord = _block_coord;
    var place_coin = random_int(0, 2);
    if (block_coord) {
      var t = block_coord[1];
      var h = block_coord[0];
      if (place_coin) {
        _block_coord = t;
        continue ;
        
      } else {
        var xc = h[1][0];
        var yc = h[1][1];
        return $at(/* :: */[
                    /* tuple */[
                      0,
                      /* tuple */[
                        xc,
                        yc - 16
                      ]
                    ],
                    /* [] */0
                  ], generate_coins(t));
      }
    } else {
      return /* [] */0;
    }
  }
}

function choose_block_pattern(blockw, blockh, cbx, cby, prob) {
  if (cbx > blockw || cby > blockh) {
    return /* [] */0;
  } else {
    var block_typ = random_int(0, 4);
    var stair_typ = random_int(0, 2);
    var life_block_chance = random_int(0, 5);
    var middle_block = life_block_chance ? stair_typ : 3;
    if (prob > 5 || prob < 0) {
      return failwith("Shouldn't reach here");
    } else {
      switch (prob) {
        case 0 : 
            if (blockw - cbx > 2) {
              return /* :: */[
                      /* tuple */[
                        stair_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* :: */[
                        /* tuple */[
                          middle_block,
                          /* tuple */[
                            cbx + 1,
                            cby
                          ]
                        ],
                        /* :: */[
                          /* tuple */[
                            stair_typ,
                            /* tuple */[
                              cbx + 2,
                              cby
                            ]
                          ],
                          /* [] */0
                        ]
                      ]
                    ];
            } else if (blockw - cbx > 1) {
              return /* :: */[
                      /* tuple */[
                        block_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* :: */[
                        /* tuple */[
                          block_typ,
                          /* tuple */[
                            cbx + 1,
                            cby
                          ]
                        ],
                        /* [] */0
                      ]
                    ];
            } else {
              return /* :: */[
                      /* tuple */[
                        block_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* [] */0
                    ];
            }
        case 1 : 
            var num_clouds = random_int(0, 5) + 5 | 0;
            if (cby < 5) {
              return generate_clouds(cbx, cby, 2, num_clouds);
            } else {
              return /* [] */0;
            }
        case 2 : 
            if (blockh - cby === 1) {
              var cbx$1 = cbx;
              var cby$1 = cby;
              var typ = stair_typ;
              var four_000 = /* tuple */[
                typ,
                /* tuple */[
                  cbx$1,
                  cby$1
                ]
              ];
              var four_001 = /* :: */[
                /* tuple */[
                  typ,
                  /* tuple */[
                    cbx$1 + 1,
                    cby$1
                  ]
                ],
                /* :: */[
                  /* tuple */[
                    typ,
                    /* tuple */[
                      cbx$1 + 2,
                      cby$1
                    ]
                  ],
                  /* :: */[
                    /* tuple */[
                      typ,
                      /* tuple */[
                        cbx$1 + 3,
                        cby$1
                      ]
                    ],
                    /* [] */0
                  ]
                ]
              ];
              var four = /* :: */[
                four_000,
                four_001
              ];
              var three_000 = /* tuple */[
                typ,
                /* tuple */[
                  cbx$1 + 1,
                  cby$1 - 1
                ]
              ];
              var three_001 = /* :: */[
                /* tuple */[
                  typ,
                  /* tuple */[
                    cbx$1 + 2,
                    cby$1 - 1
                  ]
                ],
                /* :: */[
                  /* tuple */[
                    typ,
                    /* tuple */[
                      cbx$1 + 3,
                      cby$1 - 1
                    ]
                  ],
                  /* [] */0
                ]
              ];
              var three = /* :: */[
                three_000,
                three_001
              ];
              var two_000 = /* tuple */[
                typ,
                /* tuple */[
                  cbx$1 + 2,
                  cby$1 - 2
                ]
              ];
              var two_001 = /* :: */[
                /* tuple */[
                  typ,
                  /* tuple */[
                    cbx$1 + 3,
                    cby$1 - 2
                  ]
                ],
                /* [] */0
              ];
              var two = /* :: */[
                two_000,
                two_001
              ];
              var one_000 = /* tuple */[
                typ,
                /* tuple */[
                  cbx$1 + 3,
                  cby$1 - 3
                ]
              ];
              var one = /* :: */[
                one_000,
                /* [] */0
              ];
              return $at(four, $at(three, $at(two, one)));
            } else {
              return /* [] */0;
            }
        case 3 : 
            if (stair_typ === 0 && blockh - cby > 3) {
              var cbx$2 = cbx;
              var cby$2 = cby;
              var typ$1 = stair_typ;
              var three_000$1 = /* tuple */[
                typ$1,
                /* tuple */[
                  cbx$2,
                  cby$2
                ]
              ];
              var three_001$1 = /* :: */[
                /* tuple */[
                  typ$1,
                  /* tuple */[
                    cbx$2 + 1,
                    cby$2
                  ]
                ],
                /* :: */[
                  /* tuple */[
                    typ$1,
                    /* tuple */[
                      cbx$2 + 2,
                      cby$2
                    ]
                  ],
                  /* [] */0
                ]
              ];
              var three$1 = /* :: */[
                three_000$1,
                three_001$1
              ];
              var two_000$1 = /* tuple */[
                typ$1,
                /* tuple */[
                  cbx$2 + 2,
                  cby$2 + 1
                ]
              ];
              var two_001$1 = /* :: */[
                /* tuple */[
                  typ$1,
                  /* tuple */[
                    cbx$2 + 3,
                    cby$2 + 1
                  ]
                ],
                /* [] */0
              ];
              var two$1 = /* :: */[
                two_000$1,
                two_001$1
              ];
              var one_000$1 = /* tuple */[
                typ$1,
                /* tuple */[
                  cbx$2 + 5,
                  cby$2 + 2
                ]
              ];
              var one_001 = /* :: */[
                /* tuple */[
                  typ$1,
                  /* tuple */[
                    cbx$2 + 6,
                    cby$2 + 2
                  ]
                ],
                /* [] */0
              ];
              var one$1 = /* :: */[
                one_000$1,
                one_001
              ];
              return $at(three$1, $at(two$1, one$1));
            } else if (blockh - cby > 2) {
              var cbx$3 = cbx;
              var cby$3 = cby;
              var typ$2 = stair_typ;
              var one_000$2 = /* tuple */[
                typ$2,
                /* tuple */[
                  cbx$3,
                  cby$3
                ]
              ];
              var one_001$1 = /* :: */[
                /* tuple */[
                  typ$2,
                  /* tuple */[
                    cbx$3 + 1,
                    cby$3
                  ]
                ],
                /* [] */0
              ];
              var one$2 = /* :: */[
                one_000$2,
                one_001$1
              ];
              var two_000$2 = /* tuple */[
                typ$2,
                /* tuple */[
                  cbx$3 + 3,
                  cby$3 - 1
                ]
              ];
              var two_001$2 = /* :: */[
                /* tuple */[
                  typ$2,
                  /* tuple */[
                    cbx$3 + 4,
                    cby$3 - 1
                  ]
                ],
                /* [] */0
              ];
              var two$2 = /* :: */[
                two_000$2,
                two_001$2
              ];
              var three_000$2 = /* tuple */[
                typ$2,
                /* tuple */[
                  cbx$3 + 4,
                  cby$3 - 2
                ]
              ];
              var three_001$2 = /* :: */[
                /* tuple */[
                  typ$2,
                  /* tuple */[
                    cbx$3 + 5,
                    cby$3 - 2
                  ]
                ],
                /* :: */[
                  /* tuple */[
                    typ$2,
                    /* tuple */[
                      cbx$3 + 6,
                      cby$3 - 2
                    ]
                  ],
                  /* [] */0
                ]
              ];
              var three$2 = /* :: */[
                three_000$2,
                three_001$2
              ];
              return $at(one$2, $at(two$2, three$2));
            } else {
              return /* :: */[
                      /* tuple */[
                        stair_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* [] */0
                    ];
            }
        case 4 : 
            if (cby + 3 - blockh === 2) {
              return /* :: */[
                      /* tuple */[
                        stair_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* [] */0
                    ];
            } else if (cby + 3 - blockh === 1) {
              return /* :: */[
                      /* tuple */[
                        stair_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* :: */[
                        /* tuple */[
                          stair_typ,
                          /* tuple */[
                            cbx,
                            cby + 1
                          ]
                        ],
                        /* [] */0
                      ]
                    ];
            } else {
              return /* :: */[
                      /* tuple */[
                        stair_typ,
                        /* tuple */[
                          cbx,
                          cby
                        ]
                      ],
                      /* :: */[
                        /* tuple */[
                          stair_typ,
                          /* tuple */[
                            cbx,
                            cby + 1
                          ]
                        ],
                        /* :: */[
                          /* tuple */[
                            stair_typ,
                            /* tuple */[
                              cbx,
                              cby + 2
                            ]
                          ],
                          /* [] */0
                        ]
                      ]
                    ];
            }
        case 5 : 
            return /* :: */[
                    /* tuple */[
                      3,
                      /* tuple */[
                        cbx,
                        cby
                      ]
                    ],
                    /* [] */0
                  ];
        
      }
    }
  }
}

function generate_enemies(blockw, blockh, _cbx, _cby, acc) {
  while(true) {
    var cby = _cby;
    var cbx = _cbx;
    if (cbx > blockw - 32) {
      return /* [] */0;
    } else if (cby > blockh - 1 || cbx < 15) {
      _cby = 0;
      _cbx = cbx + 1;
      continue ;
      
    } else if (mem_loc(/* tuple */[
            cbx,
            cby
          ], acc) || cby === 0) {
      _cby = cby + 1;
      continue ;
      
    } else {
      var prob = random_int(0, 30);
      if (prob < 3 && blockh - 1 === cby) {
        var enemy_000 = /* tuple */[
          prob,
          /* tuple */[
            cbx * 16,
            cby * 16
          ]
        ];
        var enemy = /* :: */[
          enemy_000,
          /* [] */0
        ];
        return $at(enemy, generate_enemies(blockw, blockh, cbx, cby + 1, acc));
      } else {
        _cby = cby + 1;
        continue ;
        
      }
    }
  }
}

function generate_block_enemies(_block_coord) {
  while(true) {
    var block_coord = _block_coord;
    var place_enemy = random_int(0, 20);
    var enemy_typ = random_int(0, 3);
    if (block_coord) {
      var t = block_coord[1];
      var h = block_coord[0];
      if (place_enemy) {
        _block_coord = t;
        continue ;
        
      } else {
        var xc = h[1][0];
        var yc = h[1][1];
        return $at(/* :: */[
                    /* tuple */[
                      enemy_typ,
                      /* tuple */[
                        xc,
                        yc - 16
                      ]
                    ],
                    /* [] */0
                  ], generate_block_enemies(t));
      }
    } else {
      return /* [] */0;
    }
  }
}

function generate_block_locs(blockw, blockh, _cbx, _cby, _acc) {
  while(true) {
    var acc = _acc;
    var cby = _cby;
    var cbx = _cbx;
    if (blockw - cbx < 33) {
      return acc;
    } else if (cby > blockh - 1) {
      _cby = 0;
      _cbx = cbx + 1;
      continue ;
      
    } else if (mem_loc(/* tuple */[
            cbx,
            cby
          ], acc) || cby === 0) {
      _cby = cby + 1;
      continue ;
      
    } else {
      var prob = random_int(0, 100);
      if (prob < 5) {
        var newacc = choose_block_pattern(blockw, blockh, cbx, cby, prob);
        var undup_lst = avoid_overlap(newacc, acc);
        var called_acc = $at(acc, undup_lst);
        _acc = called_acc;
        _cby = cby + 1;
        continue ;
        
      } else {
        _cby = cby + 1;
        continue ;
        
      }
    }
  }
}

function generate_panel(context, blockw, blockh) {
  return spawn(/* SBlock */__(3, [/* Panel */4]), context, /* tuple */[
              blockw * 16 - 256,
              blockh * 16 * 2 / 3
            ]);
}

function generate_ground(blockw, blockh, _inc, _acc) {
  while(true) {
    var acc = _acc;
    var inc = _inc;
    if (inc > blockw) {
      return acc;
    } else if (inc > 10) {
      var skip = random_int(0, 10);
      var newacc = $at(acc, /* :: */[
            /* tuple */[
              4,
              /* tuple */[
                inc * 16,
                blockh * 16
              ]
            ],
            /* [] */0
          ]);
      if (skip === 7 && blockw - inc > 32) {
        _inc = inc + 1;
        continue ;
        
      } else {
        _acc = newacc;
        _inc = inc + 1;
        continue ;
        
      }
    } else {
      var newacc$1 = $at(acc, /* :: */[
            /* tuple */[
              4,
              /* tuple */[
                inc * 16,
                blockh * 16
              ]
            ],
            /* [] */0
          ]);
      _acc = newacc$1;
      _inc = inc + 1;
      continue ;
      
    }
  }
}

function convert_to_block_obj(lst, context) {
  if (lst) {
    var h = lst[0];
    var sblock_typ = choose_sblock_typ(h[0]);
    var ob = spawn(/* SBlock */__(3, [sblock_typ]), context, h[1]);
    return $at(/* :: */[
                ob,
                /* [] */0
              ], convert_to_block_obj(lst[1], context));
  } else {
    return /* [] */0;
  }
}

function convert_to_enemy_obj(lst, context) {
  if (lst) {
    var h = lst[0];
    var senemy_typ = choose_enemy_typ(h[0]);
    var ob = spawn(/* SEnemy */__(1, [senemy_typ]), context, h[1]);
    return $at(/* :: */[
                ob,
                /* [] */0
              ], convert_to_enemy_obj(lst[1], context));
  } else {
    return /* [] */0;
  }
}

function convert_to_coin_obj(lst, context) {
  if (lst) {
    var ob = spawn(/* SItem */__(2, [/* Coin */3]), context, lst[0][1]);
    return $at(/* :: */[
                ob,
                /* [] */0
              ], convert_to_coin_obj(lst[1], context));
  } else {
    return /* [] */0;
  }
}

function generate_helper(blockw, blockh, _, _$1, context) {
  var block_locs = generate_block_locs(blockw, blockh, 0, 0, /* [] */0);
  var converted_block_locs = trim_edges(convert_list(block_locs), blockw, blockh);
  var obj_converted_block_locs = convert_to_block_obj(converted_block_locs, context);
  var ground_blocks = generate_ground(blockw, blockh, 0, /* [] */0);
  var obj_converted_ground_blocks = convert_to_block_obj(ground_blocks, context);
  var block_locations = $at(block_locs, ground_blocks);
  var all_blocks = $at(obj_converted_block_locs, obj_converted_ground_blocks);
  var enemy_locs = generate_enemies(blockw, blockh, 0, 0, block_locations);
  var obj_converted_enemies = convert_to_enemy_obj(enemy_locs, context);
  var coin_locs = generate_coins(converted_block_locs);
  var undup_coin_locs = trim_edges(avoid_overlap(coin_locs, converted_block_locs), blockw, blockh);
  var converted_block_coin_locs = $at(converted_block_locs, coin_locs);
  var enemy_block_locs = generate_block_enemies(converted_block_locs);
  var undup_enemy_block_locs = avoid_overlap(enemy_block_locs, converted_block_coin_locs);
  var obj_enemy_blocks = convert_to_enemy_obj(undup_enemy_block_locs, context);
  var coin_objects = convert_to_coin_obj(undup_coin_locs, context);
  var obj_panel = generate_panel(context, blockw, blockh);
  return $at(all_blocks, $at(obj_converted_enemies, $at(coin_objects, $at(obj_enemy_blocks, /* :: */[
                          obj_panel,
                          /* [] */0
                        ]))));
}

function generate(w, h, context) {
  var blockw = w / 16;
  var blockh = h / 16 - 1;
  var collide_list = generate_helper(blockw, blockh, 0, 0, context);
  var player = spawn(/* SPlayer */__(0, [
          /* SmallM */1,
          /* Standing */0
        ]), context, /* tuple */[
        100,
        224
      ]);
  return /* tuple */[
          player,
          collide_list
        ];
}

function init() {
  return /* () */0;
}


/* No side effect */

// Generated by BUCKLESCRIPT VERSION 1.7.2, PLEASE EDIT WITH CARE
var loadCount = [0];

function inc_counter() {
  loadCount[0] = loadCount[0] + 1 | 0;
  if (loadCount[0] === 4) {
    var canvas_id = "canvas";
    var match = document.getElementById(canvas_id);
    var canvas = match !== null ? match : (console.log("can find canvas " + (String(canvas_id) + "")), failwith("fail"));
    var context = canvas.getContext("2d");
    document.addEventListener("keydown", keydown, true);
    document.addEventListener("keyup", keyup, true);
    init(/* () */0);
    update_loop(canvas, generate(2400, 256, context), /* tuple */[
          2400,
          256
        ]);
    console.log("asd");
    return /* () */0;
  } else {
    return /* () */0;
  }
}

function preload() {
  return map(function (img_src) {
              var img_src$1 = "sprites/" + img_src;
              var img = document.createElement("img");
              img.src = img_src$1;
              img.addEventListener("load", function () {
                    inc_counter(/* () */0);
                    return true;
                  }, true);
              return /* () */0;
            }, /* :: */[
              "blocks.png",
              /* :: */[
                "items.png",
                /* :: */[
                  "enemies.png",
                  /* :: */[
                    "mario-small.png",
                    /* [] */0
                  ]
                ]
              ]
            ]);
}

window.onload = function () {
  preload(/* () */0);
  return true;
};


/*  Not a pure module */

}());
